package automation;

/**
 * Access modifier in java
 * public  - resource can be accessible inside package or outside the same package
 * private - only accessible in the same class
 * protected - Same package or derived class
 * default - same package
 */
public class ConstructorExample {
	public static void main(String[] args) {
		Student std1 = new Student(1,"Abc","A","Pune",1234l,22);
		System.out.println("Main method - ");
		System.out.println(std1.getMarks());
		std1.giveExam();
	}
}
class A{
	
}
//method
// access modifier return type name(paras)
class Student{
	int roll;
	String name;
	String div;
	String add;
	long mob;
	int age;
	
	public Student() {

	}
	public Student(int roll, String name, String div, String add, long mob, int age) {
		this.roll = roll;
		this.name = name;
		this.div = div;
		this.add = add;
		this.mob = mob;
		this.age = age;
	}

	public int getMarks() {
		System.out.println("Get marks called");
		return 97;
	}
	public void giveExam() {
		System.out.println("Give Exam called");
	}

	public String toString() {
		return "Student [roll=" + roll + ", name=" + name + ", div=" + div + ", add=" + add + ", mob=" + mob + ", age="
				+ age + "]";
	}
}