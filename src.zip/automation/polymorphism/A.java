package automation.polymorphism;

public class A {
	public void foo(int a) {
		System.out.println("a = "+a);
	}
	
	public void foo(int a,int b) {
		System.out.println("a = "+a+" b = "+b);
	}
	public void foo(int a,double b) {
		System.out.println("a = "+a+" b = "+b);
	}
	public void foo(double b,int a) {
		System.out.println("a = "+a+" b = "+b);
	}
	
	public static void main(String[] args) {
		A obj = new A();
		obj.foo(10);
		obj.foo(10,20);
		obj.foo(10,10.2);
		obj.foo(10.2,19);
	}
}
