package automation.polymorphism;

public class Parent1 {
	public void m1(int i) {
		System.out.println(i);
	}
}
class child extends Parent1{
	public void m1(int i) {
		System.out.println(i*i);
	}
}


class Person{
	int age;
	String name;
	long mob;
	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", mob=" + mob + "]";
	}
	
}
class Dev extends Person{
	
}
class Test extends Person{
	
}
class Main{
	public static void main(String[] args) {
		Dev d = new Dev();
		d.age=22;
		d.name="abc";
		d.mob=1234l;
		
		Test t = new Test();
		t.age=20;
		t.name="xyz";
		t.mob=98776l;
		
		System.out.println(d);
		System.out.println(t);
	}
}