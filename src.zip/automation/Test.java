package automation;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		System.out.println("hello mayur");
		int a,b,ans;
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter values for a and b");
		a=sc.nextInt();
		b=sc.nextInt();
		ans=a+b;//+ - * / %
		
		System.out.print("Final addition = ");
		System.out.print(ans);
	}
}
