package automation.inheritance;

public interface Interface1 {
	int a=10;
	public void m1();
}
