package automation.inheritance;

public class Class1 implements Interface1{
	public void add() {}
	public void m1() {
		System.out.println("M1 of class1");
	}
}


class Class2 implements Interface1,Interface2{
	public void m1() {
		System.out.println("M1 of class2");
	}
	public void m2() {
		System.out.println("m2 of class 2");
	}
}

class Test2{
	public static void main(String[] args) {
		Class1 ob1 = new Class1();
		Class2 ob2 = new Class2();
		
		ob1.m1();
		ob2.m1();
		
		
	}
}