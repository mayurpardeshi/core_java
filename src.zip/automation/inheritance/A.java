package automation.inheritance;

public class A {
	public int add(int a,int b) {
		return a+b;
	}
	public int sub(int a, int b) {
		return a-b;
	}
	
}

class B extends A{ //sinle inheritance when B extends A
	public int mul(int a,int b) {
		return a*b;
	}
}

class C extends B{ // multilevel inheritance when C extends B and B extends A
}

class Test{
	public static void main(String[] args) {
		B b = new B();
		int ans  = b.add(10, 20);
		System.out.println("add = "+ans);
		C c = new C();
		ans = c.mul(2,5);
		System.out.println("mul = "+ans);
		ans = c.sub(10, 4);
		System.out.println("sub = "+ans);
	}
}
