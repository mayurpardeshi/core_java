package automation.inheritance;

public interface Interface2 {
	public void m2();
}
